<?php

$base_url ="http://localhost/kasir/user/";
$admin_url ="http://localhost/kasir/admin/";

?>