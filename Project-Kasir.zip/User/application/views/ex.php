hallooo

<?php
    echo base_url();
    echo "<br>";
    echo site_url();
?>

<a href="<?=base_url('welcome/wel')?>">klik</a>